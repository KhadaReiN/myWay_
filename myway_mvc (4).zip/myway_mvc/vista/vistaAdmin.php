<?php

    
    //include_once 'controlador/ControladorUsuario.php';
    
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title>vistaAdmin</title>
</head>
<body>

    <h1>Panel de administrador</h1>

    
    <table>
        <thead>
            <tr>
            <td>Id</td>
            <td>Primer Nombre</td>
            <td>Segundo Nombre</td>
            <td>Primer Apellido</td>
            <td>Segundo Apellido</td>
            <td>Numero de contacto</td>
            <td>Correo electrónico</td>
            <td>Genero</td>
            <td>Rol</td>
            </tr>
        </thead>
        <tbody>
            
            <?php
                require_once $_SERVER['DOCUMENT_ROOT'] . '/myway_mvc/controlador/ControladorUsuario.php';
                $controlador = new ControladorUsuario();
                $lista = $controlador->listar();
                foreach ($lista as $item) {
                    echo "<tr>";
                    foreach($item as $attribute){
                        
                        echo "<td>".$attribute."</td>";
                        
                        
                    }
                    ?>
                    <td>
                        <a href="../index.php?action=editar&id=<?=$item['idUsuario']?>">
             
                            <i class="fa-regular fa-pen-to-square"></i>
                        </a>
                        <a href="../index.php?action=eliminar&id=<?=$item['idUsuario']?>">
                            <i class="fa-regular fa-trash-can"></i>
                        </a>
                    </td>
                    
                    
                    <?php
                    echo "</tr>";
                    
                    
                    
            
                    
                }              
            
            ?>
        </tbody>
    </table>
</body>
</html>