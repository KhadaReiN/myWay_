<?php 

require_once $_SERVER['DOCUMENT_ROOT'] . '/myway_mvc/controlador/ControladorUsuario.php';
$controlador = new ControladorUsuario();
$usuario = $controlador->$modelo->obtenerUsuarioPorId($_GET['id']);
echo 'holaaaaaaaaaaaa'
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <form method="POST" action="../index.php?action=actualizar&id=<?=$$usuario['idUsuario']?>" id="editar">
        <h1>Editar usuario</h1>
            <label>Nombre</label>
            <section id="mensajeNombre"></section>
            <input name="nombre" id="nombreRe" type="text" placeholder=" ">

            <label>Número de contacto</label>
            <section id="mensajeContacto"></section>
            <input name="contacto" id="contactoRe" type="text" placeholder=" ">

            <label>Correo</label>
            <section id="mensajeCorreoRe"></section>
            <input name="correo" id="emailRe" type="email" placeholder=" ">

            <label>Contraseña</label>
            <section id="mensajeContraRe"></section>
            <input name="contrasena" id="contraRe" type="password" placeholder=" ">

            <label>Genero</label>
            <select name="genero" id="generoRe">
                <option>Femenino</option>
                <option>Masculino</option>
            </select>

            
        </section>
        <button id="registrar" type="submit">Registrarse</button>
        <a href="./index.php"><button id="opcion" onclick="cambiarForm()">Iniciar Sesion</button></a>

    </form>
</body>

</html>