<?php
    session_start();
    

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>vistaAdmin</title>
</head>
<body>

    <h1>Panel de administrador</h1>

    
    <table>
        <thead>
            <tr>
            <td>Primer Nombre</td>
            <td>Segundo Nombre</td>
            <td>Primer Apellido</td>
            <td>Segundo Apellido</td>
            <td>Numero de contacto</td>
            <td>Correo electrónico</td>
            <td>Rol</td>
            </tr>
        </thead>
        <tbody>
            
            <?php
                require_once './controlador/ControladorUsuario.php';

                $controlador = new ControladorUsuario();

                $lista = $controlador->listar();
                foreach ($item as $lista) {
                    echo "<tr>"
                    ."<td>".$item["primerNombre"]."</td>"
                    ."<td>".$item["segundoNombre"]."</td>"
                    ."<td>".$item["primerApellido"]."</td>"
                    ."<td>".$item["segundoApellido"]."</td>"
                    ."<td>".$item["correo"]."</td>"
                    ."<td>".$item["contacto"]."</td>"
                    ."<td>".$item["genero"]."</td>"
                    ."<td>".$item["rol"]."</td>"
                    ."</tr>";
                }                
            
            ?>
        </tbody>
    </table>
</body>
</html>