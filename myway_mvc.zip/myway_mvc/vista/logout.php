<?php if (isset($_SESSION['usuario'])): ?>
    <p>Bienvenido, <?= $_SESSION['usuario']['nombre'] ?> | <a href="index.php?action=logout">Cerrar Sesión</a></p>
<?php endif; ?>