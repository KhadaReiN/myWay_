<!DOCTYPE html>
<html lang="en">
<head>
    <title>Log in</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/styleR.css">
    <link rel="stylesheet" href="assets/fonts/classy_vogue/Classyvogueregular.ttf">
</head>
<body>
    <img src="https://stellular-paprenjak-29667f.netlify.app/img/Frame39.svg" alt="MyWay Logo" id="logo">
    <section id="container">
        <img src="assets/img/snazzy-image.png" alt="mapa" id="imagen">
        <form method="POST" action="index.php?action=guardar" id="registro" onsubmit="return validateFormRe()"> 
            <h1>Registrate</h1>
            <section class="entradaRe">
                <label>Nombre</label>
                <section id="mensajeNombre"></section>
                <input name="nombre" id="nombreRe" type="text" placeholder=" ">
            </section>
            <section class="entradaRe">
                <label>Número de contacto</label>
                <section id="mensajeContacto"></section>
                <input name="contacto" id="contactoRe" type="text" placeholder=" ">
            </section>

            <section class="entradaRe">
                <label>Correo</label>
                <section id="mensajeCorreoRe"></section>
                <input name="correo" id="emailRe" type="email" placeholder=" ">
            </section>
            <section class="entradaRe">
                <label>Contraseña</label>
                <section id="mensajeContraRe"></section>
                <input name="contrasena" id="contraRe" type="password" placeholder=" ">
            </section>
            
            <section class="entradaRe">
                <label>Genero</label>
                <select name="genero" id="generoRe">
                    <option>Femenino</option>
                    <option>Masculino</option>
                </select>
            </section>
            <button id = "registrar" type="submit">Registrarse</button>
            <a href="./index.php"><button id="opcion" onclick="cambiarForm()">Iniciar Sesion</button></a>

        </form>
    </section>
</body>
</html>
<script src="./js/main.js"></script>