<?php
session_start();
if (isset($_SESSION['usuario'])) {
    $usuario = $_SESSION['usuario'];
    echo "Bienvenido, " . $usuario['primerNombre'];
} else {
    header('Location: ../index.php');
}
?>
