<!DOCTYPE html>
<html lang="en">
<head>
    <title>Log in</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/styleL.css">
    <link rel="stylesheet" href="assets/fonts/classy_vogue/Classyvogueregular.ttf">
</head>
<body>
    <img src="https://stellular-paprenjak-29667f.netlify.app/img/Frame39.svg" alt="MyWay Logo" id="logo">
    <section id="container">
        <img src="assets/img/snazzy-image.png" alt="mapa" id="imagen">
        <form method="POST" id="inicio" action="index.php?action=login" onsubmit="return validateForm()">
            <h1>Inicia sesión</h1>
            <section class="entrada">
                <label id="la">Correo</label>
                <section id="mensajeCorreo"></section>
                <input id="emailInicio" name="correo" type="email" placeholder=" ">
            </section>
            <section class="entrada">
                <label>Contraseña</label>
                <section id="mensajeContra"></section>
                <input id="contraInicio" name="contrasena" type="password" placeholder=" ">
            </section>
            <button type="submit" id="iniciarSesion" onclick="validateForm()">iniciar sesión</button>
            <a href="?action=crear"><button type="button" id="opcion">Registrarse</button></a>
        </form>
        
    </section>
</body>
</html>
<script src="assets/js/main.js"></script>