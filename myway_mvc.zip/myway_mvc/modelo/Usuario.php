<?php
require_once 'Conexion.php';

class Usuario
{
    private $conexion;

    public function __construct()
    {
        $this->conexion = (new Conexion())->getConexion();
    }
    //Creacion del CRUD

    //CREAR
    public function crearUsuario($nombre_completo, $fotoDePerfil, $numero_contacto, $correo, $contrasena, $genero, $idRol)
    {
        $nombre_descompuesto = (explode(' ', $nombre_completo));
        $hash_contraseña = password_hash($contrasena, PASSWORD_DEFAULT);
        $this->conexion->begin_transaction();
        try {
            //Stmt para crear el usuario en la tabla usuarios
            $stmt_usuarios = $this->conexion->prepare("INSERT INTO usuarios(primerNombre, segundoNombre, primerApellido, segundoApellido, fotoDePerfil, contacto, correo, contrasena, genero, idRol) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt_usuarios->bind_param("ssssbssssi", $nombre_descompuesto[0], $nombre_descompuesto[1], $nombre_descompuesto[2], $nombre_descompuesto[3], $fotoDePerfil, $numero_contacto, $correo, $hash_contraseña, $genero, $idRol);
            $stmt_usuarios->execute();

            $this->conexion->commit();
            return true;
        } catch (Exception $e) {
            $this->conexion->rollback();
            return false;
        }
    }

    //ACTUALIZAR
    //public function actualizarUsuario($id, $nombre, $correo, $idRol) {
    //$stmt = $this->conexion->prepare("UPDATE usuarios SET nombre = ?, correo = ?, idRol = ? WHERE idUsuario = ?");
    //    $stmt->bind_param("ssii", $nombre, $correo, $idRol, $idUsuario);
    //  return $stmt->execute();
    // }
    //OBTENER
    public function obtenerUsuarios()
    {
        $resultado = $this->conexion->query("SELECT u.idUsuario, u.primerNombre, u.segundoNombre, u.primerApellido, u.segundoApellido, u.contacto, u.correo, r.nombre AS rol FROM usuarios u JOIN roles r ON u.idRol = r.idRol");
        return $resultado->fetch_all(PDO::FETCH_ASSOC);
    }

    // Obtener usuario por ID
    public function obtenerUsuarioPorId($id)
    {
        $stmt = $this->conexion->prepare("SELECT * FROM usuarios WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc();
    }

    //ELIMINAR
    public function eliminarUsuario($id)
    {
        $stmt = $this->conexion->prepare("DELETE FROM usuarios WHERE id = ?");
        $stmt->bind_param("i", $id);
        return $stmt->execute();
    }


    //Funciones de acceso
    public function validarLogin($correo, $contrasena)
    {

        // Preparar la consulta SQL
        $stmt = $this->conexion->prepare("SELECT u.idUsuario, u.primerNombre, u.primerApellido, u.contrasena, r.nombre AS rol  FROM usuarios u JOIN roles r ON u.idRol = r.idRol WHERE u.correo = ?");
        //$stmt = $this->conexion->prepare("SELECT u.idUsuario, u.primerNombre, u.primerApellido, r.nombre FROM usuarios u JOIN roles r ON idRol = r.idRol WHERE u.correo = ?");
        $stmt->bind_param("s", $correo);
        $stmt->execute();
        //$stmt->bind_result($contrasena);
        //$stmt->fetch();
        $usuario = $stmt->get_result()->fetch_assoc();

        if ($usuario && password_verify($contrasena, $usuario['contrasena'])) {
            return $usuario;
        }
        return false;
    }

    /*
            // Asignar el parámetro (correo)
            $stmt->bind_param("s", $correo);
        
            // Ejecutar la consulta
            $stmt->execute();
        
            // Obtener el resultado
            $resultado = $stmt->get_result();
        
            // Verificar si se encontró un usuario con el correo ingresado
            if ($resultado) {
                // Convertir el resultado a un arreglo asociativo
                $usuario = $resultado->fetch_assoc();
        
                // Verificar la contraseña ingresada con la contraseña almacenada (hasheada)
                if (password_verify($contrasena, $usuario['contrasena'])) {
                    // Si las contraseñas coinciden, devolver el usuario
                    return $usuario;
                }
            }
        
            // Si no se encontró el usuario o la contraseña no coincide, devolver false
            return false;
        }
        
*/
}
