var mensajeCorreo = document.getElementById('mensajeCorreo');
var mensajeContra = document.getElementById('mensajeContra');
var mensajeCorreoRe = document.getElementById('mensajeCorreoRe');
var mensajeContraRe = document.getElementById('mensajeContraRe');
var mensajeNombre = document.getElementById('mensajeNombre');
var mensajeFecha = document.getElementById('mensajeFecha');
var correoInicio;
var contraInicio;
var correoRe;
var contraRe;
var nombre;
var fecha;
//validacion de campos
function validateForm() {
    correoInicio = document.getElementById("emailInicio").value;
    contraInicio = document.getElementById("contraInicio").value;
    var envia = true;

    // Restablecer mensajes de error
    mensajeCorreo.innerHTML = '';
    mensajeContra.innerHTML = '';
    // Validar correo
    if (!validateEmail(correoInicio)) {
        mensajeCorreo.innerHTML = "Por favor, ingresa un correo válido.";
        envia = false; // Impedir que el formulario se envíe
    }

    // Validar contraseña (ejemplo: al menos 6 caracteres)
    if (contraInicio.length < 6) {
        mensajeContra.innerHTML = "La contraseña debe tener al menos 6 caracteres.";
        envia = false; // Impedir que el formulario se envíe
    }

    // Si todo está correcto, el formulario se enviará
    return envia;
}

function validateEmail(correo) {
    var re = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
    return re.test(correo);
}

function validateFormRe() {
    correoRe = document.getElementById("emailRe").value;
    contraRe = document.getElementById("contraRe").value;
    nombre = document.getElementById('nombreRe').value;
    fecha = document.getElementById('fecha')
    var envia = true;
    // Restablecer mensajes de error
    mensajeCorreoRe.innerHTML = '';
    mensajeContraRe.innerHTML = '';
    mensajeNombre.innerHTML = '';
    mensajeFecha.innerHTML = '';

    // Validar correo
    if (!validateEmail(correoRe)) {
        mensajeCorreoRe.innerHTML = "Por favor, ingresa un correo válido.";
        envia = false; // Impedir que el formulario se envíe
    }

    // Validar contraseña (ejemplo: al menos 6 caracteres)
    if (contraRe.length < 6) {
        mensajeContraRe.innerHTML = "La contraseña debe tener al menos 6 caracteres.";
        envia = false; // Impedir que el formulario se envíe
    }

    if (nombre === "") {
        mensajeNombre.innerHTML = "Debe ingresar su nombre";
        envia = false;
    }

    if (fecha.value === "") {
        mensajeFecha.innerHTML = "Debe ingresar su fecha de nacimiento";
        envia = false;
    }

    if (envia === true) {
        setTimeout(alerta, 5000);
    }
    // Si todo está correcto, el formulario se enviará
    return envia;
}

function alerta() {
    Swal.fire({
        title: 'Te has registrado correctamente',
        text: 'Serás redirigido a la página de inicio de sesión',
        icon: 'success',
        confirmButtonText: 'Continuar'
    });
}