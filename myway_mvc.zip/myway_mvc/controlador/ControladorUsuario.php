<?php
require_once 'modelo/Usuario.php';

class ControladorUsuario {
    private $modelo;

    public function __construct() {
        $this->modelo = new Usuario();
    }

    // Verificar si el usuario es administrador
    private function verificarAccesoAdministrador() {
        session_start();
        if (!isset($_SESSION['correo']) || $_SESSION['correo']['rol'] != 'Administrador') {
            header('Location: index.php?action=login');
            exit;
        }
    }

    // Mostrar la lista de usuarios (solo administrador)
    public function listar() {
        $this->verificarAccesoAdministrador();
        $usuarios = $this->modelo->obtenerUsuarios();
        return $usuarios;
    }

    // Mostrar formulario de creación
    public function mostrarFormularioCrear() {
        require 'vista/registro.php';
    }

    // Procesar la creación de un usuario
    public function crear() {
        //$this->verificarAccesoAdministrador();
        $nombre = $_POST['nombre'];
        $fotoDePerfil = NULL;//$_POST['fotoDePerfil'];
        $contacto = $_POST['contacto'];
        $correo = $_POST['correo'];
        $sexo = $_POST['genero'];
        $idRol = 1;
        $contrasena = $_POST['contrasena'];

        $this->modelo->crearUsuario($nombre, $fotoDePerfil, $contacto, $correo, $contrasena, $sexo, $idRol);
        header('Location: index.php');
    }

    // Mostrar formulario de edición
    public function mostrarFormularioEditar($id) {
        $this->verificarAccesoAdministrador();
        $usuario = $this->modelo->obtenerUsuarioPorId($id);
        require 'vista/usuarios/vistaAdmin.php';
    }

    // Procesar la actualización de un usuario
    public function actualizar($id) {
        $this->verificarAccesoAdministrador();
        $nombre = $_POST['nombre'];
        $correo = $_POST['correo'];
        $idRol = $_POST['idRol'];

        //$this->modelo->actualizarUsuario($id, $nombre, $correo, $idRol);
        header('Location: index.php');
    }

    // Eliminar usuario
    public function eliminar($id) {
        $this->verificarAccesoAdministrador();
        $this->modelo->eliminarUsuario($id);
        header('Location: index.php');
    }

    // Mostrar formulario de login
    public function mostrarFormularioLogin() {
        require 'vista/login.php';
    }

    // Procesar inicio de sesión
    public function login() {

        $correo = $_POST['correo'];
        $contrasena = $_POST['contrasena'];
        $usuario = $this->modelo->validarLogin($correo, $contrasena);
        
        
        
        if ($usuario) {
            session_start();
            $_SESSION['usuario'] = $usuario;
        

            
           
            if($_SESSION['usuario']['rol']=="Administrador"){header('Location: vista/vistaAdmin.php');}
            else {header('Location: vista/bienvenida.php');}
                
        } else {
            header('Location: index.php?action=login&error=1');
        }
            
    }

    // Procesar cierre de sesión
    public function logout() {
        session_start();
        session_destroy();
        header('Location: index.php?action=login');
    }

    //Ver perfil
    public function verPerfil($id){
        session_start();
        $this->verificarAccesoAdministrador();
        $usuario = $this->modelo->obtenerUsuarioPorId($id);
        require 'vista/usuarios/perfil.php';
    }


}