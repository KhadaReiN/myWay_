<?php
return [
    'host' => 'localhost',
    'usuario' => 'root',
    'contrasena' => '',
    'base_de_datos' => '10-10-mvc-mw'
];
?>
