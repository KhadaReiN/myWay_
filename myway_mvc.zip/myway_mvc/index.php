<?php
require_once 'controlador/ControladorUsuario.php';

$controlador = new ControladorUsuario();

if (isset($_GET['action'])) {
    switch ($_GET['action']) {
        case 'crear':
            $controlador->mostrarFormularioCrear();
            break;

        case 'guardar':
            $controlador->crear();
            break;

        case 'editar':
            $controlador->mostrarFormularioEditar($_GET['id']);
            break;

        case 'actualizar':
            $controlador->actualizar($_GET['id']);
            break;

        case 'eliminar':
            $controlador->eliminar($_GET['id']);
            break;

        case 'login':
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                $controlador->login();
           } else {
                $controlador->mostrarFormularioLogin();
            }
            break;
        
        case 'perfil':
            $controlador->verPerfil($_GET['id']);
            break;
        
        case 'logout':
            $controlador->logout();
            break;

        default:
            $controlador->listar();
            break;
    }
} else {
    $controlador->mostrarFormularioLogin();
}